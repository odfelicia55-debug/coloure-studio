COLOURÉ STUDIO STARTER WEBSITE

Files:
- index.html, styles.css, script.js: public storefront
- products.json: product catalogue data
- admin/index.html and admin/config.yml: Decap CMS dashboard configuration

IMPORTANT:
This starter storefront is a catalogue only. It does not process payments, calculate shipping, or place Printify orders.
The CMS configuration uses Netlify Git Gateway / Netlify Identity. Before the dashboard can be used, deploy the site to a Git-connected Netlify site, configure Identity and Git Gateway if those features are available for your account, and update the site URL in admin/config.yml. Provider setup and availability may change; verify the current Netlify instructions before relying on this login method.
Do not publish with placeholder contact email or without checking every product photo, price, product link and fulfilment cost.
